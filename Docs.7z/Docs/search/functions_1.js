var searchData=
[
  ['getdwmattribute_0',['GetDwmAttribute',['../main_8c.html#aeb324c029a8834197603522a00a42eb4',1,'main.c']]],
  ['getmousemonitor_1',['getmousemonitor',['../main_8c.html#a1f9a8b87bafd3cc91f4ad6d26282d761',1,'GetMouseMonitor(sMonitor *monitor, INT sz):&#160;main.c'],['../main_8h.html#a1f9a8b87bafd3cc91f4ad6d26282d761',1,'GetMouseMonitor(sMonitor *monitor, INT sz):&#160;main.c']]]
];
