var searchData=
[
  ['g_5fcurrentmonitor_0',['g_CurrentMonitor',['../main_8c.html#aeb4289ee3b1caf2ca2b43b014e2ca635',1,'main.c']]],
  ['g_5feventhook_1',['g_eventHook',['../main_8c.html#aadff10890677d1ab973ed3f5a7942e9f',1,'main.c']]],
  ['g_5fhwnd_2',['g_hwnd',['../main_8c.html#a803a83328c6891b81d6f47569ddc3ef0',1,'main.c']]],
  ['g_5fhwnd_5ftaskswitcher_3',['g_hwnd_taskswitcher',['../main_8c.html#aa8986fd4f1d91d28a9965ea648a708b1',1,'main.c']]],
  ['g_5fkeyboardhook_4',['g_keyboardHook',['../main_8c.html#aea35fc69904a03f60a75697ffd3c1fa6',1,'main.c']]],
  ['g_5fmonitors_5',['g_monitors',['../main_8c.html#aedbbc466813ceb504b810c8e57f728eb',1,'main.c']]],
  ['g_5fnum_5fmonitors_6',['g_num_monitors',['../main_8c.html#add44db3d3e45178b2138f5bea533be41',1,'main.c']]],
  ['g_5ftaskswitchername_7',['g_taskswitcherName',['../main_8c.html#a2c224f1a13c8384a56f585a94da342b5',1,'main.c']]]
];
