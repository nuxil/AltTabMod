var searchData=
[
  ['code_0',['Compile the code!.',['../index.html#autotoc_md6',1,'']]],
  ['collectmonitorinfo_1',['collectmonitorinfo',['../main_8c.html#a9012ff127b84a8fc288611bcf2b743f0',1,'CollectMonitorInfo(sMonitor *monitor):&#160;main.c'],['../main_8h.html#a9012ff127b84a8fc288611bcf2b743f0',1,'CollectMonitorInfo(sMonitor *monitor):&#160;main.c']]],
  ['compile_20the_20code_2',['Compile the code!.',['../index.html#autotoc_md6',1,'']]],
  ['credits_3',['Credits.',['../index.html#autotoc_md9',1,'']]]
];
