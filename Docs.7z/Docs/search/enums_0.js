var searchData=
[
  ['oscheck_0',['OsCheck',['../main_8h.html#a0ed0a68cf864e3bca8fbfe352e528b96',1,'main.h']]]
];
