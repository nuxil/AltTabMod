var searchData=
[
  ['application_2emanifest_0',['Application.manifest',['../_application_8manifest.html',1,'']]]
];
