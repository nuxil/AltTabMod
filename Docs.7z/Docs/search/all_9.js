var searchData=
[
  ['license_0',['License',['../index.html#autotoc_md10',1,'']]],
  ['limitations_20and_20issues_1',['Known Limitations and Issues',['../index.html#autotoc_md3',1,'']]]
];
