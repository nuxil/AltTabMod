var searchData=
[
  ['i_20made_20this_0',['Background why i made this.',['../index.html#autotoc_md8',1,'']]],
  ['idi_5fappicon_1',['IDI_APPICON',['../main_8h.html#a987166b75dc07f55aa2adf5ba6e38d63',1,'main.h']]],
  ['in_20alt_20tab_2',['How It Moves The Programs In (Alt+Tab).',['../index.html#autotoc_md4',1,'']]],
  ['in_20this_20project_3',['Tools used in this project.',['../index.html#autotoc_md5',1,'']]],
  ['isapp3d_4',['IsApp3D',['../main_8c.html#a3d577f5e6ad82e1e390786090178207f',1,'main.c']]],
  ['isdirectxmodule_5',['IsDirectXModule',['../main_8c.html#a0f0270d7ffa408fa5275d3d6c03a7025',1,'main.c']]],
  ['isopenglmodule_6',['IsOpenGLModule',['../main_8c.html#ad40d7a567204e77472ff28d42a657367',1,'main.c']]],
  ['isprimary_7',['isPrimary',['../structs_monitor.html#a59eb6180631ed14e403b91d72fd08468',1,'sMonitor']]],
  ['issues_8',['Known Limitations and Issues',['../index.html#autotoc_md3',1,'']]],
  ['isvulkanmodule_9',['IsVulkanModule',['../main_8c.html#a146aa8a67db9acd8331dec1eafd01525',1,'main.c']]],
  ['it_20moves_20the_20programs_20in_20alt_20tab_10',['How It Moves The Programs In (Alt+Tab).',['../index.html#autotoc_md4',1,'']]]
];
