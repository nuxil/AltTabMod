var searchData=
[
  ['note_0',['!!!NOTE!!!',['../index.html#autotoc_md2',1,'']]]
];
