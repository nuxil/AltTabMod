var searchData=
[
  ['isapp3d_0',['IsApp3D',['../main_8c.html#a3d577f5e6ad82e1e390786090178207f',1,'main.c']]],
  ['isdirectxmodule_1',['IsDirectXModule',['../main_8c.html#a0f0270d7ffa408fa5275d3d6c03a7025',1,'main.c']]],
  ['isopenglmodule_2',['IsOpenGLModule',['../main_8c.html#ad40d7a567204e77472ff28d42a657367',1,'main.c']]],
  ['isvulkanmodule_3',['IsVulkanModule',['../main_8c.html#a146aa8a67db9acd8331dec1eafd01525',1,'main.c']]]
];
