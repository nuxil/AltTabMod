var searchData=
[
  ['win10_0',['WIN10',['../main_8h.html#a0ed0a68cf864e3bca8fbfe352e528b96a93dd9e7ff81dad9515d54a07860d056c',1,'main.h']]],
  ['win7_1',['WIN7',['../main_8h.html#a0ed0a68cf864e3bca8fbfe352e528b96a9320c0d3187f1f620d0156769b9371f4',1,'main.h']]]
];
