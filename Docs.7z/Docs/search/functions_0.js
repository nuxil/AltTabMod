var searchData=
[
  ['collectmonitorinfo_0',['collectmonitorinfo',['../main_8c.html#a9012ff127b84a8fc288611bcf2b743f0',1,'CollectMonitorInfo(sMonitor *monitor):&#160;main.c'],['../main_8h.html#a9012ff127b84a8fc288611bcf2b743f0',1,'CollectMonitorInfo(sMonitor *monitor):&#160;main.c']]]
];
