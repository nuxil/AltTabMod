var searchData=
[
  ['readme_2emd_0',['ReadMe.md',['../_read_me_8md.html',1,'']]],
  ['resource_2erc_1',['resource.rc',['../resource_8rc.html',1,'']]]
];
