var searchData=
[
  ['wm_5fevent_5ftaskswitcher_0',['WM_EVENT_TASKSWITCHER',['../main_8h.html#a33a1812b147e03bc6fa3ff00b2026370',1,'main.h']]]
];
