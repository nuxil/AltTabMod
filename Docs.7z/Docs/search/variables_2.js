var searchData=
[
  ['isprimary_0',['isPrimary',['../structs_monitor.html#a59eb6180631ed14e403b91d72fd08468',1,'sMonitor']]]
];
