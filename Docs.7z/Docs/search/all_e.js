var searchData=
[
  ['readme_2emd_0',['ReadMe.md',['../_read_me_8md.html',1,'']]],
  ['rect_1',['rect',['../structs_monitor.html#a58ac9e5c1f54c1ec3e930e7ecf0d6a39',1,'sMonitor']]],
  ['rect_5finside_2',['RECT_INSIDE',['../main_8h.html#adf8c0f600b75601000457270ce1844cd',1,'main.h']]],
  ['resource_2erc_3',['resource.rc',['../resource_8rc.html',1,'']]],
  ['run_20the_20program_4',['Run the program.',['../index.html#autotoc_md7',1,'']]]
];
