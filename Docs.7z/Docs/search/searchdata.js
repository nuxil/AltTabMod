var indexSectionsWithContent =
{
  0: "abcdeghiklmnoprstuw",
  1: "s",
  2: "amr",
  3: "cgiw",
  4: "egirw",
  5: "ops",
  6: "op",
  7: "euw",
  8: "imrw",
  9: "adp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

