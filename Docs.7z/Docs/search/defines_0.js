var searchData=
[
  ['idi_5fappicon_0',['IDI_APPICON',['../main_8h.html#a987166b75dc07f55aa2adf5ba6e38d63',1,'main.h']]]
];
