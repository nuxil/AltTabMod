var files_dup =
[
    [ "Application.manifest", "_application_8manifest.html", null ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "main.h", "main_8h.html", "main_8h" ],
    [ "makefile", "makefile.html", null ],
    [ "resource.rc", "resource_8rc.html", null ]
];