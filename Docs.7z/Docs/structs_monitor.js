var structs_monitor =
[
    [ "isPrimary", "structs_monitor.html#a59eb6180631ed14e403b91d72fd08468", null ],
    [ "rect", "structs_monitor.html#a58ac9e5c1f54c1ec3e930e7ecf0d6a39", null ]
];