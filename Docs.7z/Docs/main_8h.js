var main_8h =
[
    [ "sMonitor", "structs_monitor.html", "structs_monitor" ],
    [ "IDI_APPICON", "main_8h.html#a987166b75dc07f55aa2adf5ba6e38d63", null ],
    [ "mmon", "main_8h.html#afaf81f1194f764d8206df1efe46258e2", null ],
    [ "RECT_INSIDE", "main_8h.html#adf8c0f600b75601000457270ce1844cd", null ],
    [ "WM_EVENT_TASKSWITCHER", "main_8h.html#a33a1812b147e03bc6fa3ff00b2026370", null ],
    [ "OsCheck", "main_8h.html#a5144760c491220e100be5d22d4108085", null ],
    [ "prgErr", "main_8h.html#a6bce5ed5cac7ae11f648e07c558e51cc", null ],
    [ "sMonitor", "main_8h.html#a45ac346d0ab7c6e7f74be72678130e07", null ],
    [ "OsCheck", "main_8h.html#a0ed0a68cf864e3bca8fbfe352e528b96", [
      [ "UNKNOWN", "main_8h.html#a0ed0a68cf864e3bca8fbfe352e528b96a6ce26a62afab55d7606ad4e92428b30c", null ],
      [ "WIN10", "main_8h.html#a0ed0a68cf864e3bca8fbfe352e528b96a93dd9e7ff81dad9515d54a07860d056c", null ],
      [ "WIN7", "main_8h.html#a0ed0a68cf864e3bca8fbfe352e528b96a9320c0d3187f1f620d0156769b9371f4", null ]
    ] ],
    [ "prgErr", "main_8h.html#a0f783af8dfd87182a58dc3ef6bbb962c", [
      [ "ERR0", "main_8h.html#a0f783af8dfd87182a58dc3ef6bbb962caee68ca14bd42b83c1d796f49bf4ad203", null ],
      [ "ERR1", "main_8h.html#a0f783af8dfd87182a58dc3ef6bbb962ca78872e320a40a52cccabc0b5b392e6f6", null ],
      [ "ERR2", "main_8h.html#a0f783af8dfd87182a58dc3ef6bbb962caceb8c2e6386733c07b9e5e4a7c881897", null ],
      [ "ERR3", "main_8h.html#a0f783af8dfd87182a58dc3ef6bbb962ca0b33b66e9da176737d00405189208fd5", null ],
      [ "ERR4", "main_8h.html#a0f783af8dfd87182a58dc3ef6bbb962ca324c934201c4898ee322dc69b65f15df", null ],
      [ "ERR5", "main_8h.html#a0f783af8dfd87182a58dc3ef6bbb962ca663dac87a0288c33ee30e27d34ae3e17", null ],
      [ "ERR6", "main_8h.html#a0f783af8dfd87182a58dc3ef6bbb962caa2ca9170a79f25df117aee289dbb0f6b", null ],
      [ "ERR7", "main_8h.html#a0f783af8dfd87182a58dc3ef6bbb962caad4658cafaced6369ad36f657ea715ff", null ],
      [ "ERR8", "main_8h.html#a0f783af8dfd87182a58dc3ef6bbb962caddf64b274098451ad95c4c719549613b", null ]
    ] ],
    [ "CollectMonitorInfo", "main_8h.html#a9012ff127b84a8fc288611bcf2b743f0", null ],
    [ "GetMouseMonitor", "main_8h.html#a1f9a8b87bafd3cc91f4ad6d26282d761", null ],
    [ "WinEventProc_Win10", "main_8h.html#ada84b1077699d946a8143dd85330ea5a", null ],
    [ "WinEventProc_Win7", "main_8h.html#a1c7bb51969b3308ce9234a6f927ed1d1", null ],
    [ "WinKeyboardProc", "main_8h.html#a513e520abb5c93af29d6335fce130594", null ],
    [ "WinMain", "main_8h.html#a39ae444eab243a86ae2115dfc4d4218c", null ],
    [ "WinProc", "main_8h.html#a057bcfb850ff9a7c278e2a382298db80", null ]
];